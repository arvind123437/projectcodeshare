package Test1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.examples.xssf.usermodel.IterateCells;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariDriver.WindowType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class interviewTest {

	WebDriver driver;

	String cs_url;

	private WebElement editor2;

	private String wind;

	private WebElement editor;

	private String TextEditor2;

	@BeforeClass
	public void ShareCodeNow_browser() {
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		System.setProperty("webdriver.chrome.driver",
				"E:\\Selenium\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(options);
		this.driver = driver;
		driver.get("https://codeshare.io/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	}

//	@AfterClass
//	public void quitBrowser() {
//		
//		driver.quit();
//	}

	@Test(priority = 1)
	public void ShareCodeNow_ShareNowBtn() throws InterruptedException {

		WebElement ShareNowBtn = driver.findElement(By.xpath("//a[@class = 'btn-primary']"));
		cs_url = ShareNowBtn.getAttribute("href");
		ShareNowBtn.click();

//		Thread.sleep(4000);
//		WebElement ad = driver.findElement(By.xpath("//button[@class = 'btn-icon btn-hide']"));
//		ad.click();
	}

	@Test(priority = 2)
	public void ShareCodeNow_SendKeysEditorOne() throws InterruptedException {
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		WebElement editor = driver.findElement(
				By.xpath("//div[@role= 'presentation' and @style = 'position: relative; outline: none;' ]"));
		this.editor = editor;
		Actions action = new Actions(driver);
		action.sendKeys(editor, "#include <stdio.h>").build().perform();
		Thread.sleep(2000);

	}

	@Test(priority = 3)
	public void ShareCodeNow_SecondWindow() {
		String wind = driver.getWindowHandle();
		this.wind = wind;
		System.out.println(wind);

		((JavascriptExecutor) driver).executeScript("window.open()");

//		Set<String> winds = driver.getWindowHandles();
//		Iterator<String> itr = winds.iterator();
//		String secondWindow = itr.next();
//		driver.switchTo().window(secondWindow);

		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs);
		driver.switchTo().window(tabs.get(1));
		driver.get(cs_url);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test(priority = 4)
	public void ShareCodeNow_VerifyText() {
		WebElement editor2 = driver.findElement(
				By.xpath("//div[@role= 'presentation' and @style = 'position: relative; outline: none;' ]"));
		SoftAssert verify = new SoftAssert();
		String text = editor2.getText();
		this.editor2 = editor2;
		verify.assertEquals(text, "#include <stdio.h>");
	}

	@Test(priority = 5)
	public void ShareCodeNow_SendKeysOnSecondEditor() {
		Actions act = new Actions(driver);
		act.sendKeys(editor2, "#include <stdio.h>", "\n", "#include <conio.h>").build().perform();
		String TextEditor2 = editor2.getText();
		this.TextEditor2 = TextEditor2;
	}

	@Test(priority = 6)
	public void ShareCodeNow_SwitchToParentWindow() throws InterruptedException {
		driver.switchTo().window(wind);
		Thread.sleep(4000);
		SoftAssert verify = new SoftAssert();
		verify.assertEquals(TextEditor2, "#include <stdio.h>");
		verify.assertEquals(TextEditor2, "#include <conio.h>");
	}

}
